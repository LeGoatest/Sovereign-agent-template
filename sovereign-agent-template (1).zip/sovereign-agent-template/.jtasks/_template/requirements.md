# Requirements

## Functional Requirements
- **R1**: Description
- **R2**: Description

## Non-Functional Requirements
- **N1**: Description
- **N2**: Description
