# Tasks

- [ ] **Task 1**: Description
  - Task Group: [Group]
  - Skill: [Skill]
  - Outputs: [Files]
- [ ] **Task 2**: Description
  - Task Group: [Group]
  - Skill: [Skill]
  - Outputs: [Files]
