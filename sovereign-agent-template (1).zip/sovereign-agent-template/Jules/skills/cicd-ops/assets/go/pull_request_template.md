## Checklist
- [ ] gofmt clean
- [ ] go test ./... passes
- [ ] golangci-lint passes
- [ ] No architecture rule violations (see docs/ARCHITECTURE_RULES.md)
