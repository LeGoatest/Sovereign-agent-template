# Project Name | Terminology

## Core Terms
- **Term 1**: Definition
- **Term 2**: Definition
