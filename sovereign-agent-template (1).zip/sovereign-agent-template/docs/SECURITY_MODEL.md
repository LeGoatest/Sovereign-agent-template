# Project Name | Security Model

## 1) Threat Model
- [Define primary threats and protected assets]

## 2) Trust Boundaries
- [Define where trust begins and ends]

## 3) Mandatory Controls
- [Define non-negotiable security controls]
