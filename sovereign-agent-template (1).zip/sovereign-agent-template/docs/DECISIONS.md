# Project Name | Architectural Decisions

## [YYYY-MM-DD] Decision Name
- **Status**: [Proposed/Accepted/Deprecated]
- **Context**: Why are we doing this?
- **Decision**: What did we decide?
- **Consequences**: What happens next?
