# Project Name | Enforcement Matrix

| Rule | Enforced By | Failure Mode |
|-----|-----------|--------------|
| Rule Name | [Agent / CI / Runtime] | [Refusal / Build Fail] |
